
Clerk.markdown(
    Text.fillOut(
"""
# Funktionsplotter
        
_Thierry Florent Dzouato Djeumen_

Betrachtet man die Entwicklung der letzten Jahren,
so kann man feststellen, dass viele SchülerInnen sowie einige Studierende
es schwer haben, mit dem Plotten von Funktionen und deren Verhalten umzugehen.
Daraus ergibt sich die Frage, ob es nicht sinnvoll wäre, ein Programm zu erstellen,
das nicht nur Ihnen helfen wird, sondern auch einige Lehrer es einfacher Ihnen diese Konzepten beizubringen.
Das Thema meines Dokumentations lautet.
Ich habe ein ___Funktiionsplotter___ erstellt und habe die Implementierung in 5 Szenarien eingeteilt.
###                     BERÜCKSICHTIGEN BITTE MEIN NEUES FUNKTIONSVERSPRECHEN WIE GESPROCHEN. [OpenItHere 😉](./5553824_Frunktionsversprechen.pdf)

## SZEANRIO 1(plot) und 5(Anzeigebereich wählen)
```
void setFunction(String function){
    this.currentFunction = function;
}

void plotFunction(double minX, double maxX, double minY, double maxy) {
    if(minX >= maxX){
        System.out.println("Invalid range(minX must be less than maxX).");
        return;
    }

    if(minY >= maxY){
        System.out.println("Invalid range(minY must be less than maxY).");
        return;
    }

    //check if a function has actuallx been entered
    if(currentFunction == null || currentFunction.isEmpty()){
        throw new IllegalArgumentException("Go and set a a function MY FRIENNDD");
    }

    plotFunction();
    functions.add(this.currentFunction);
}

void plotFunction(){
    int steps = 100; //No of points in domain
    for(int i = 0; i <= steps; i++){
            double x = minX + (maxX - minX) * i / steps;
            double y = evaluateFunction(currentFunction, x);

        //Only show points of the y axis, i.e in the range
        if(y >= minY && y <= maxY){
            System.out.printf("Point: (x = %.2f, y = %.2f)%n", x, y);
            //Historik aktualisieren
            history.addEntry(currentFunction, x, y);
        }
            
        if(x == minX){
            pl.moveTo(x, y);
        }else{
            pl.lineTo(x, y);
        }
    }

    functions.add(this.currentFunction);
    //Historie danach anzeigen
    //history.printHistory();
}
```
Um eine Funktion zu plotten kann man folgende Befehle in der jshell aufrufen.
Zuerst erstellt man ein neues Objekt mit __PlotterView pv = new PlotterView()__
Hier habe ich den default Konstruktor benutzt, aber man kann auch die Koordinaten
für die Achsen selbst beim Erstellen angeben.
Dann macht man ein "set" mit __pv.set("sin(x)"), angenommen "sin(x)" ist die Funktion,
die von der Benutzer geplottet wird.
Um Szenario 1 zu erfüllen, kann man ein pv.plotFunction() machen, aber falls man
eher den 5.Szenario erfüllen möchte, kann man __pv.plotFunction(-5,5,-5,5)__,
angenommen die Anzeigebereich, was in Klammer ist.
Anschließend wird die Funktion mithilfe des eingebenen Daten geplottet. Cool oder?
Nun stellt man sich die Frage, ob wie etwas wie zoom, pan und andere nicht machen kann.
Eine Antwort auf diese Fragen liefern uns die folgenden Szenarien
## Szenario 2 (Zoom)
Fürs Zoomen habe ich die zoom(...)-Methode implementiert, die einen Zoomfaktor als
Parameter nimmt und Modifikationen an unserer Umgebung entsprechend diesem Faktor vornehmen.
Mit einem __pv.zoom(factor<1)__ kann einzoomen und mit __pv.zoom(factor>1)__
auszoomen. Anbei der von mir implementierten Methode.
```
void zoom(double factor) {
        double centerX = (this.minX + this.maxX) / 2;
        double centerY = (this.minY + this.maxY) / 2;

        double newXRange = (this.maxX - this.minX) / factor;
        double newYRange = (this.maxY - this.minY) / factor;

        this.minX = centerX - newXRange / 2;
        this.maxX = centerX + newXRange / 2;
        this.minY = centerY - newYRange / 2;
        this.maxY = centerY + newYRange / 2;

        pl.clearCanvas();
        pl.axes(this.minX, this.maxX, this.minY, this.maxY);
        for(String function : functions){
            plotFunction();
        }
    }
```
## Szenario 3(Benutzerdefinierte Funktionen und Updates)
Damit ist gemeint, der Nutzer kann mehr als nur eine Funktion plotten. Das kann er
beim Neuen Setting machen. Mit einem __pv.setFunction("log(x)")__ und
__pv.plotFunction()__ kann er eine zweite Funktion plotten und diese kann
auf der gleichen Umgebung wie die erste Funktion geplottet werden. Wenn sowas möglich
ist, denkt man direkt an einen Vorteil, aber welcher denn? Szenario 4 kümmert sich
darum, eine Antwort darauf zu geben.
## Szenario 4(Lehrreiche Exploration)
Mit dieser Möglichkeit hätten Lernende die Möglichkeiten, Änderungen von gezeichneten
Kurven sowie Linien in Live sehen und erhöht nicht nur das Verständnis dieses Konzepts des
Plotten von Funktioinen, sondern verienfacht es auch die Arbeit der Lehrer und manche
Dozenten, die das Ganze den SchülerInnen und Studierenden beibringen wollen. Auch cool oder ?

Nun habe ich noch zusätzliche Szenarien implementiert, damit mein Programm besser wird
## Szenario 6(pan)
Erlaubt es einen Benutzer, sich auf der Plotting-Umgebung zu bewegen. Wie der zoom
nimmt diese Methode aber zwei Parameter. Mit __pv.pan(dx, dy)__ kann man die
Bewegung durchführen, wobei dx(change in x) und dy(change in y). Anbei die Methode...

```
void pan(double dx, double dy){
    this.minX += dx;
    this.maxX += dx;
    this.minY += dy;
    this.maxY += dy;

    //Neuzeichnen
    pl.clearCanvas();
    pl.axes(this.minX, this.maxX, this.minY, this.maxY);
    
    for(String function : functions){
        plotFunction();
    }
}
```
Ein Record, die alle berechnete Punkten enthält. Ist das nicht eine tolle Idee.
Das denke ich sowieso, daher habe ich eine in einer anderen Klasse implementiert.
Die __PlotterHistory.java__ spielt diese Rolle. Mit den Methoden dieser Klasse
kann man Objekten erstellen, hinzufügen, ausdrucken, klären,... Die Klasse enthält
Methoden dafür. Anbei die Klasse

```
public class PlotterHistory {
    //Record zur Speicherung
    public record HistoryEntry(String function, double input, double result){
    }
    //Liste zur Speicherung der Historie
    final List<HistoryEntry> history;

    PlotterHistory() {
        this.history = new ArrayList<>();
    }
    
    //Neuer Eintrag hinzufügen
    void addEntry(String function, double input, double result){
        history.add(new HistoryEntry(function, input, result));
    }

    //Gesamte Historie anzeigen
    void printHistory(){
        if(history.isEmpty()) {
            System.out.println("Noch keine ausgeführte Funktion!");
            return;
        }

        System.out.println("Historie der ausgeführten Funktion(en): ");
        for(HistoryEntry entry : history) {
            System.out.printf("Funktion: %s, Input: %.2f, Ergebnis: %.2f%n", entry.function(), entry.input(), entry.result());
        }
    }

    //Historie leeren
    void clearHistory(){
        history.clear();
        System.out.println("Historie entleert!");
    }

    //Zugriff auf Historie#
    List<HistoryEntry> getHistory(){
        return new ArrayList<>(history);
    }
}
```

""", Text.cutOut("./DDTF.java", "// Szenario 1")));

Clerk.markdown(
    Text.fillOut(
"""
Das war's für mein Projekt. Vielen Dank für Ihre Mühe.
Ich würde mich auf gute, kritische und entmutige Feedbacks von Ihnen
fürs weiter Lernen freuen und verbleibe in der Hoffnung, dass Sie mit meinem
Programm und meine Implementierung zufrieden sind.

___Thierry Florent Dzouato Djeumen___
"""
    )
);




