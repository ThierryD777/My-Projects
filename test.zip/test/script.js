const decrementButton = document.querySelector('.decrement');
const incrementButton = document.querySelector('.increment');
const textWindow = document.querySelector('span');
const errorMessage = document.querySelector('.error-message');

decrementButton.addEventListener('click', () => {
    let number = Number(textWindow.textContent);

    if (number <= 0)
        errorMessage.textContent = "The number cannot be negative";
    else {
        textWindow.textContent = number - 1;
        errorMessage.textContent = "";
    }
})

incrementButton.addEventListener('click', () => {
    let number = Number(textWindow.textContent);

    if (number >= 10)
        errorMessage.textContent = "The number cannot be greater than 10";
    else {
        textWindow.textContent = number + 1;
        errorMessage.textContent = "";
    }
})